
$(function() {

    $("#menu").mmenu({}, {
        offCanvas: {
            pageSelector: ".outerwrapper"
        },
        clone: true
    });

    var heroslider = $('section.hero .owl-carousel');
    heroslider.owlCarousel({
        autoplay: true,
        autoplayTimeout: 4000,
        autoplaySpeed: 2000,
        loop: true,
        margin: 0,
        pagination: true,
        nav: false,
        navText: ['<div class="icon-left-open-big"></div>', '<div class="icon-right-open-big"></div>'],
        items: 1,
        animateOut: 'fadeOut'
    });

    var testslider = $('.test-slider.owl-carousel');
    testslider.owlCarousel({
        autoplay: true,
        autoplayTimeout: 4000,
        autoplaySpeed: 2000,
        // autoHeight: true,
        loop: true,
        margin: 0,
        pagination: true,
        nav: false,
        navText: ['<div class="icon-left-open-big"></div>', '<div class="icon-right-open-big"></div>'],
        items: 1,
        animateOut: 'fadeOut'
    });

    // $('section.hero.parallax').each(function(u, v) {
    //     var bgimg = $(this).css('background-image');
    //     bgimg = bgimg.replace('url(','').replace(')','').replace(/\"/gi, "");
    //     $(this).css('background', 'transparent');
    //     $(this).parallax({ imageSrc: bgimg });
    // });

    $('.mag-gallery').each(function(u, v) {
        $(this).magnificPopup({
            delegate: 'a',
            type: 'image',
            mainClass: 'mfp-img-mobile',
            gallery: {
                enabled: true,
                navigateByImgClick: true,
                preload: [0,1] // Will preload 0 - before current, and 1 after the current image
            },
            image: {
                tError: '<a href="%url%">The image #%curr%</a> could not be loaded.',
                titleSrc: function(item) {
                    return item.el.attr('title');
                }
            }
        });
    });

    $('.popup-youtube, .popup-vimeo, .popup-gmaps').magnificPopup({
        // disableOn: 700,
        type: 'iframe',
        mainClass: 'mfp-fade',
        removalDelay: 160,
        preloader: false,

        fixedContentPos: false
    });

    $('a.backtotop').on('click', function(e) {
        e.preventDefault();
        window.scroll({top: 0, behavior: 'smooth'});
    });

    if($('#instafeed').length && igname)
    {
        var username = igname;
        // var username = 'web_optic';
        var limit = 12;
        var instagramFeed = "https://www.weboptic.com/instagram/"+username+"/?limit="+limit;

        $.getJSON(instagramFeed, function(json) {
            console.log(json);
            if((typeof json.items === "object") && (json.items !== null))
            {
                var count = (limit+1);
                $.each(json.items, function(index, el) {
                    count--;
                    $('#instafeed').append('<a class="col col-4" target="_blank" style="opacity: 0;" href="'+el.link+'" data-id="'+el.id+'" data-date="'+el.created_time+'"><img src="'+el.images.thumbnail.url+'" /></a>').find('a').animate({opacity: 1}, 1000);
                });
            }

        });
    }

});